# Make robot world
from cs1robots import *
#load_world("./worlds/harvest4.wld")
#load_world("./worlds/harvest1.wld")
load_world("./worlds/harvest3.wld")
hubo = Robot(beepers=42)
hubo.set_trace("blue")
hubo.set_pause(0.2)
# Make turn right function
def turn_right() :
    for i in range(3):
        hubo.turn_left()
# Make function that robot move east and go up one step 
def move_east():
    while hubo.front_is_clear(): 
        if not hubo.on_beeper():
            while not hubo.on_beeper():
                hubo.drop_beeper() 
        else :
            hubo.move()
    if not hubo.on_beeper():
        hubo.drop_beeper() # Make this condition so that we can drop beeper when we go out while loop.
    hubo.turn_left()
    hubo.move() # We make this step so robot do not drop beeper in the highest avenue because we can go out loop in line 39.
# Make function that robot move west and go up one step
def move_west():
    while hubo.front_is_clear():
        if not hubo.on_beeper():
            while not hubo.on_beeper():
                hubo.drop_beeper()
        else :
            hubo.move()
    if not hubo.on_beeper():
        hubo.drop_beeper() # Make this condition so that we can drop beeper when we go out while loop.                 
    turn_right()
    hubo.move()
        
# Make a loop to make robot drop beeper
while hubo.front_is_clear() :
    move_east() 
    if hubo.front_is_clear() :
        hubo.turn_left()
    move_west()
    if hubo.front_is_clear() :
        turn_right()
        

