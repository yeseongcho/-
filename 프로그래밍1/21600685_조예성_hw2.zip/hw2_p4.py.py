# Make robot world
from cs1robots import *
import random
# Give random value to x and y
x = random.randint(1, 20)
y = random.randint(1, 20)
create_world(avenues = x, streets = y)
hubo=Robot()
hubo.set_trace("blue")
hubo.set_pause(0.1)
# Make turn right function
def turn_right() :
    for i in range(3):
        hubo.turn_left()
# Make going up function
def up_stairs() :
    while hubo.front_is_clear() :
        hubo.move()
    turn_right()
# Make going to next column function
def next_to_column() :
    if hubo.front_is_clear() :
        if hubo.right_is_clear() :
            hubo.move()
            turn_right()
        else :
            hubo.move()
            hubo.turn_left()
# Make going down function
def down_stairs() :
    while hubo.front_is_clear() :
        hubo.move()
    hubo.turn_left()
# To make it briefly, make main function
def main() :
    hubo.turn_left() # make robot's first direction 
    if hubo.front_is_clear() :
        while hubo.front_is_clear():
            up_stairs()
            next_to_column()
            down_stairs()
            next_to_column()
    else : # if y=1, at the first time, hubo's front is not clear. To deal with special case like(x or y is 1)
        turn_right()
        while hubo.front_is_clear() :
            hubo.move()
    
main()

