'''
Name: Jaehong Kim
Stuendent ID: 21400176
Description: 1723~1970년도 영국의 평균기온을 출력하는 프로그램입니다. 여름과, 겨울로 나누어 평균기온을 출력합니다.
'''
#파일을 불러와, 여름과 겨울로 나누어 평균기온을 출력하는 프로그램 메인 함수입니다.
def main():
    f = open("tpmon.txt", "r")
    winter=[]
    summer=[]
    f.readline() #첫번째줄을 skip하기 위한 장치입니다.
    for line in f:
        line = line.strip("\n")
        elements = line.split("  ")
        January=float(elements[1])
        Feburary=float(elements[2])
        July=float((elements[7]))
        August=float(elements[8])
        winter_temperature=(January + Feburary)/2
        winter.append(winter_temperature)
        summer_temperature=(July+August)/2
        summer.append(summer_temperature)
    for i in range(1723,1971): 
        print("%-4d:      %2d/%-2d" % (i, winter[i-1723], summer[i-1723])) #1723년부터 1970년도까지 index가 하나씩 올라가면, 리스트에 있는 해당 데이터가 차례로 출력되도록 구성했습니다.
    f.close
        
main()
