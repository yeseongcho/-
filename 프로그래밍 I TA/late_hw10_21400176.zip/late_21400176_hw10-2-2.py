'''
Name: Jaehong Kim
Stuendent ID: 21400176
Description: tpmon.txt 파일을 csv파일 형태로 전환하여 저장하는 프로그램입니다.
'''
#tpmon.txt 파일을 csv파일 형태로 전환하는 프로그램 메인 함수입니다.
def main():
    f = open("tpmon.txt", "r")
    n = open("tpmon.csv", "w")
    new=""
    year=1723 #년도의 초기 값입니다.
    f.readline() 
    for line in f:
        line = line.strip("\n")
        elements=line.split("  ")
        new+=str(year)+","
        for i in range(1,13):
            if i==12:
                new+=str(elements[i])+","+"\n" #12월일때, 열을 바꿔 다음 년도 data를 저장하기위한 장치입니다.
            else:
                new+=str(elements[i])+","
        year+=1 #한 line은 한 년도이므로, loop가 증가할 때마다 1을 더해주어 년도를 변화시킵니다.
    n.write(new)
    f.close
    n.close
main()
