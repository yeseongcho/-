'''
Name: Jaehong Kim
StudentID: 21400176
Description: 나라별 경도와 위도를 다루는 프로그램입니다.
'''
#파일을 불러와 tuple의 형태로 list에 할당하는 함수입니다.
def load_nations():
    f = open("average-latitude-longitude-countries.csv", "r")
    f.readline() #첫번째줄을 skip하기 위한 장치입니다.
    list1=[]
    for line in f:
        line = line.strip("\n")
        elements = line.split(",")
        code = elements[0].strip('"')
        elements[1] = elements[1].strip('"')
        if len(elements) == 4:
            name = elements[1]
            latitude = float(elements[2])
            longitude = float(elements[3])
        else: #국가 이름이 ,로 인해 분리되어 있는 경우 아래를 실행합니다.
            elements[2] = elements[2].strip('"'+ " ")
            name = elements[2] + " " + elements[1]
            latitude = float(elements[3])
            longitude = float(elements[4])
        tuple1=code, name, latitude, longitude
        list1.append(tuple1)
    return list1
    f.close()
    
def merge(left, right):
    result=[]
    i,j=0,0
    while i<len(left) and j< len(right):
        if left[i]<right[j]:
            result.append(left[i])
            i+=1
        else:
            result.append(right[j])
            j+=1
    while i<len(left): #result 리스트에 들어가지 못하고 left에 남아있는 elements를 할당합니다.
        result.append(left[i])
        i+=1
    while j<len(right):
        result.append(right[j])
        j+=1
    return result

def sort_code(L):
    for tuple in L: #나라  code를 기준으로 merge sort하기 위한 장치입니다.
        if len(tuple[0])<2:
            return tuple[0][:]
        mid =len(tuple[0])//2
        left=sort_code(tuple[0][:mid])
        right=sort_code(tuple[0][mid:])
        return merge(left,right)
    return tuple[:]
#보기 좋게 출력하는 함수입니다.
def print_sorted(A):
    for tuple in A:
        print("%-2s     %-50s   %3d  %3d" % (tuple[0], tuple[1], tuple[2], tuple[3]))

#프로그램 메인 함수 입니다.        
def main():
    list1=load_nations()
    sortedlist=sort_code(list1)
    print_sorted(list1)
    
    

main()
    
