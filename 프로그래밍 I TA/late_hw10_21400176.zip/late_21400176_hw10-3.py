'''
Name: Jaehong Kim
Stuendent ID: 21400176
Description: 웹상의 데이터를 추출하여, 날짜에 맞는 온도를 출력하는 프로그램입니다.
'''
import urllib.request
url= "http://weather.naver.com/rgn" + "/cityWetrCity.nhn?cityRgnCd=CT007023"
fname = "./montp.html"
dates = []
min_tp = []
max_tp = []

#파일을 열어 원하는 data를 출력하는 함수입니다. 
def print_weather():
    f = open('montp.html', "r")
    min_flag = True #다루고 있는 정보가 오전일때 True입니다.
    for line in f:
        if '<th scope="col"' in line: 
            wdate = extract_date(line)
            dates.append(wdate)
        elif '<th scope="row"' in line:
            wdate = extract_date(line)
            dates.append(wdate)
        elif '<li class="nm">' in line : 
            temp = extract_temperature(line)
            if min_flag == True :
                min_tp.append(temp) 
                min_flag = False #오전 데이터가 처리된 후에는, 오후 데이터를 다루기 때문에 flag를 False로 전환합니다.
            else:
                max_tp.append(temp)
                min_flag = True
    for i in range( len( dates ) ):
        print("%s :\t%5s ~ %5s" % ( dates[i], min_tp[i], max_tp[i] ))
    f.close()

#날짜를 추출하는 함수입니다.
def extract_date(line):
    if "<span>(" in line:
        tdate =line[line.find( "(") + 1 : line.find( ")" ) ]
    else:
        skip_len = len( "<span>" )
        start_idx = line.find( "<span>" ) + skip_len
        tdate =line[ start_idx : line.find( "<", start_idx)] #라인에 "<"가 많기 때문에 start_idx를 따로 명시하여, 그것부터 찾을 수 있도록 합니다.
        tdate = tdate.strip(".")
        tdate = tdate.replace(".", "/")
    return tdate

#온도를 추출하는 함수입니다.
def extract_temperature(line):
    skip_len = len( '<span class="temp">' )
    start_idx =line.find( '<span class="temp">' ) +skip_len
    end_idx = line.find("<", start_idx)
    temp = line[ start_idx : end_idx]
    return temp

#웹페이지를 가져와 컴퓨터에 저장합니다.
def process_webpage():
    webpage = urllib.request.urlopen( url )
    out = open( fname, "w" )
    for line in webpage :
        line = str(line)
        out.write( line.strip() + "\n" )
    webpage.close()
    out.close()
#프로그램 메인함수입니다.        
def main():
    process_webpage()
    print_weather()
  
main()
