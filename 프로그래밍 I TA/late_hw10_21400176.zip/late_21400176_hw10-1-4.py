'''
Name: Jaehong Kim
StudentID: 21400176
Description: 위도가 0 이상인 data를 출력하고, 사용자로 부터 국가코드를 받아 해당 코드에 부합하는 data를 출력하여 보여주는 프로그램입니다.
'''
#위도가 0도 이상인 data를 출력하는 프로그램 메인함수입니다.
def problem1():
    f = open("average-latitude-longitude-countries.csv", "r")
    f.readline() #첫번째줄을 skip하기 위한 장치입니다.
    dic1={}
    for line in f:
        line = line.strip("\n")
        elements = line.split(",")
        code = elements[0].strip('"')
        elements[1] = elements[1].strip('"')
        if len(elements) == 4:
            name = elements[1]
            latitude = float(elements[2])
            longitude = float(elements[3])
        else: #국가 이름이 ,로 인해 분리되어 있는 경우 아래를 실행합니다.
            elements[2] = elements[2].strip('"'+ " ")
            name = elements[2] + " " + elements[1]
            latitude = float(elements[3])
            longitude = float(elements[4])
        if latitude>0:
            dic1[code]= name, latitude, longitude
    for item in dic1:
        print("%-2s     %-50s   %3d  %3d" % (item, dic1[item][0], dic1[item][1], dic1[item][2]))
    f.close()

#파일을 불러와 tuple의 형태로 list에 할당하는 함수입니다.
def load_nations():
    f = open("average-latitude-longitude-countries.csv", "r")
    f.readline() #첫번째줄을 skip하기 위한 장치입니다.
    dic2={}
    for line in f:
        line = line.strip("\n")
        elements = line.split(",")
        code = elements[0].strip('"')
        elements[1] = elements[1].strip('"')
        if len(elements) == 4:
            name = elements[1]
            latitude = float(elements[2])
            longitude = float(elements[3])
        else: #국가 이름이 ,로 인해 분리되어 있는 경우 아래를 실행합니다.
            elements[2] = elements[2].strip('"'+ " ")
            name = elements[2] + " " + elements[1]
            latitude = float(elements[3])
            longitude = float(elements[4])
        dic2[code]=name, latitude, longitude
    return dic2
    f.close()
    
#사용자로부터 국가 코드를 받아옵니다.
def take_code(D):
    while True:
        code=input("Type in a country code(two letters),"+"\n"+"or type in'q'to stop >>>")
        if code=="q":
            return None
        else:
            for cd in D:
                if code==cd:
                    return cd
        print(code +"  is not in the file")

        

            
        


#프로그램 메인 함수입니다.    
def main():
    problem1()
    dic1=load_nations()
    code=take_code(dic1)    
    if code!=None:
        print("%-2s     %-50s   %3d  %3d" % (code, dic1[code][0], dic1[code][1], dic1[code
                                                                                      ][2]))
        res=input("Type in a country code(two letters),"+"\n"+"or type in'q'to stop >>>")
        if res=="q":
            return None
        else:
            main()

main()
