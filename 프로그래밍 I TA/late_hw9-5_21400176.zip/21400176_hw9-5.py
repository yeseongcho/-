'''
Name: Jaehong Kim
StudentID: 21400176
Description: 사용자가 입력한 년도의 환율의 최댓값, 최솟값, 평균 환율, 해당 년도 환율 정보의 개수를 출력하는 프로그램입니다.
'''
years=range(1994,2010)

            
#date와 환율데이터를 불러와 reformatting 하는 함수입니다.
def read_year(yr):
    fname="data/%d.txt"%yr
    f=open(fname,"r")
    data=[]
    for line in f:
        date1, value1=line.split()
        value=float(value1)
        value=round(1.0/value) #1달러당 원화가치로 변환하기 위해, 1원화당 달러 가치 데이터에 역수를 취합니다. 
        ys,ms,ds=date1.split("/")
        date=10000*int(ys)+100*int(ms)+int(ds) #읽어온 문자열 데이터를 정수 데이터로 변환하기 위한 조치입니다.
        data.append((date,value))
    f.close()
    return data

#환율의 평균을 계산하는 함수입니다.
def average(data, yr):
    sum=0
    count=0
    start=yr*10000
    end=(yr+1)*10000
    for d, v in data:
        if start<d<end: #해당년도에 value를 찾기 위한 범위 입니다.
            sum+=v
            count+=1
    return round(sum/count) #해당년도의 총합을 합해진 횟수로 나누면 평균이 됩니다.

#환율의 최소값과 해당 date를 찾는 함수입니다.
def find_min(data):
    vm=99999
    for d,v in data:
        if v < vm:
            vm=v      
    return vm
    
#환율의 최댓값과 해당 date를 찾는 함수입니다.
def find_max(data):
    vm=0
    for d,v in data:
        if v>vm:
            vm=v
    return vm


#인덱스 테이블을 만드는 함수입니다. 
def create_ind_tb(data):
    yr=1994
    inx_tb=[0]*16
    for i in range(len(data)):
        date, rate =data[i]
        year=date//10000
        if year!=yr: #년도가 변할때 마다, inx_tb의 인덱스를 변화시켜, inx_tb의 인덱스가 data의 년도별 첫번째 튜플을 가르키도록 조치합니다.
            inx_tb[year-1994]=i 
            yr=year
    return inx_tb

#사용자에게 입력 년도를 받는 함수입니다.
def take_year():
    while True:
        year=input("What year?>>>")
        for yr in years:
            if int(year)==yr:
                return yr
        print(year+"?" + "Type in a nubmer between 1994 and 2009")


    
#프로그램 메인함수입니다.    
def main():
    year=take_year()
    data=read_year(year)
    ind=create_ind_tb(data)
    k=year-1994
    data_f=data[ind[k]:] #효과적인 탐색을 위해, data의 k번째 있는 index부터 찾을 수 있도록하기 위한 조치입니다.
    print("Year=" +str(year) +", Min="+ str(find_min(data_f)) + ", Max=  "+str(find_max(data_f)) + ", average= "+ str(average(data_f, year))+ ", nu of items:" + str(len(data)))
    res=input("More yearly data? (y/n)>>>")
    if res=="y":
        main()
    if res=="n":
        return None

main()
