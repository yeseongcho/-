"""
Name: 강진
Student ID: 21600014
Description: 이 프로그램은 입력한 년도의 년도, 최대, 최소 환율, 그해 환율 평균값, 환율 평균값 개수를 보여줍니다 
"""
years = list(range(1994, 2010))

#날짜와 그 날의 환율을 담고있는 함수
def read_year(yr):
    fname = "data/%d.txt"%yr 
    f = open(fname, "r")
    data = []
    for line in f: #날짜 별로 환율 정보 읽기
        date1, value1 = line.split()
        value = float(value1) #value1 == 달러/원화
        value = round(1.0 / value)
        ys, ms, ds = date1.split("/") #년월일 순으로 나누기
        date = 10000 * int(ys) + 100 * int(ms) + int(ds) #문자열을 정수화 할 때 년도의 index 고려
        data.append((date, value))
    f.close()
    return data
#환율의 평균, 평균값의 개수를 담고있는 함수
def average(data, yr):
    sum = 0
    count = 0
    start = yr * 10000 #문자열을 정수화 할 때 년도의 index 고려
    end = (yr+1) * 10000
    for d, v in data:
        if start < d < end:
            sum += v 
            count += 1 
    return (round(sum / count), count)
#연도별 가장 작은 환율값을 찾는 함수
def find_min(data):
    vm = 99999
    for d, v in data:
        if v < vm: #환율이 99999보다 작을 것이라는 가정 하에 최소값 찾기
            vm = v
            dm = d
    return vm 
#연도별 가장 큰 환율값을 찾는 함수
def find_max(data):
    vm = 0
    for d, v in data:
        if v > vm: #환율이 0보다 클 것이라는 가정 하에 최대값 찾기
            vm = v
            dm = d
    return vm
#해당연도에서 1994년을 뺀 결과를 인덱스로, 해당정보를 갖고 오는 함수
def create_ind_tb(data):
    yr = 1994
    inx_tb = [0] * 16 
    for i in range(len(data)):
        date, rate = data[i]
        year = date // 10000
        if year != yr: #새 년도를 만날 때
            inx_tb[year - 1994] = i #inx_tb의 인덱스
            yr = year
    return inx_tb

def main(): 
    while True:
        yr = input("what year? >")
        if yr.isdigit(): 
            yr = int(yr) 
            if yr in years:
                data = read_year(yr)
                max2 = find_max(data)
                min2 = find_min(data)
                avg = average(data, yr)[0]
                count = average(data, yr)[1]
                print("Year = %4d, Min = %4d , Max = %4d, average = %4d, no of items = %3d" %(yr, min2, max2, avg, count))
            else: #입력한 숫자가 1994년 2009년 사이의 범위가 아닐 때
                print("%d? Type in a year between 1994 and 2009" %yr) 
                
            res = input("More yearly data? (y/n)")
            if res == "y": 
                continue
            elif res == "n": 
                break
            else: #입력한 게 y,n 둘 다 아닐 때
                print("please enter y/n!")
                break
            
        else: #yr에 입력한 게 숫자가 아닐 경우
            break
#보여주세요
main()
                   
