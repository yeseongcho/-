'''
name: 임태하
student ID: 21600600
description: The test file, "tpmon.txt" contains temperature information of London for years 1723~1970.
Each line of the file has the monthly average temperatures of a year. Read the file and print the average
summer and winter temperature report as shown in the lecture.
'''
#problem 2-1 : Monthly Temperature of England

#Print the average summer and winter temperature report
def main():
    data = create_list_with_files()
    for i in range(248):
        yr = data[i][0]
        summer = find_summer_temp(data[i])
        winter = find_winter_temp(data[i])
        print("%25s:  %5.2f/%.2f" % (yr, winter, summer))

#Read given file and create list of temperature data
def create_list_with_files():
    data = []
    f = open("tpmon.txt", "r")
    f.readline()
    for line in f:
        line = line.strip("\n")
        line = line.strip(" ")
        temp_info = line.split("  ")
        data.append(temp_info)
    for i in range(248):
        data[i].insert(0, str(1723 + i))
    f.close()    
    return data

#Calculate average winter temperature
'''
parameter: list
'''
def find_winter_temp(lst):
    temp = (float(lst[1]) + float(lst[2])) / 2
    return temp

#Calculate average summer temperature
'''
parameter: list
'''
def find_summer_temp(lst):
    temp = (float(lst[7]) + float(lst[8])) / 2
    return temp

main()
