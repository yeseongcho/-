'''
name: 임태하
student ID: 21600600
description: The test file, "tpmon.txt" contains temperature information of London for years 1723~1970.
Each line of the file has the monthly average temperatures of a year. Create the temperature data file
(file name: montp.csv) in a csv format in which comma, "," is used as the separator.

'''
#problem 2-2 : Monthly Temperature of England

#Create csv file of monthly average temperatures of a year in the text file
def main():
    data = create_list_with_files()
    create_csv_file(data)

#Read given file and create list of temperature data
def create_list_with_files():
    data = []
    f = open("tpmon.txt", "r")
    f.readline()
    for line in f:
        line = line.strip("\n")
        line = line.strip(" ")
        temp_info = line.split("  ")
        data.append(temp_info)
    for i in range(248):
        data[i].insert(0, str(1723 + i))
    f.close()    
    return data

#Create csv file of temperature data
'''
parameter : list
'''
def create_csv_file(data):
    f = open("montp.csv", "w")
    for i in range(len(data)):
        line = ','.join(data[i])    
        f.write(line + "\n")
    f.close()
    
main()
