'''
name: 임태하
student ID: 21600600
description: The file, average-latitude-longitude-countries.csv contains global
coordinate data by nations. Based on problem 1-2 and problem 1-3, use dictionary only
to Print info of countries above equator then print the corresponding country name and global coordinate data
'''
#problem 1-4 : Global coordinate data

#Print info of countries above equator then print the corresponding country name and global coordinate data
def main():
    data = create_dict_with_files()
    print_above_equator(data)
    while True:
        try:
            s = input("\nType in a country code(two letters), \n or type in 'q' to stop >>>")
            if s == "q":
                return None
            elif data[s]:
                name, lati, longi = data[s]          
                print("code = %3s ; name = %s ; latitude = %4.1f ; longitude = %4.1f" % (s, name, lati, longi))
        except:
            print(s+" is not in the file")
            
#Read given file and create dictonary of information
def create_dict_with_files():
    data_dict = {}
    f = open("average-latitude-longitude-countries.csv", "r")
    f.readline()
    for line in f:
        line = line.strip("\n")
        elements = line.split(",")
        code = elements[0].strip('"')
        elements[1] = elements[1].strip('"')
        if len(elements) == 4:
            name = elements[1]
            latitude = float(elements[2])
            longitude = float(elements[3])
        else:
            elements[2] = elements[2].strip('"' + " ")
            name = elements[2] + " " + elements[1]
            latitude = float(elements[3])
            longitude = float(elements[4])
        data_dict[code] = [name, latitude, longitude]
    f.close()    
    return data_dict   

#Print all countries which are in the north of the equator
'''
parameter:
    dict = dictionary
'''
def print_above_equator(dict):
    for keys, values in dict.items():
        name, lati, longi = values
        if lati > 0:
            print("%3s  %-45s %8.2f  %8.2f" % (keys, name, lati, longi))

main()

