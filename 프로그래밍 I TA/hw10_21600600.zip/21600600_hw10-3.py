'''
name: 임태하
student ID: 21600600
description: Suppose that you want to extract the weather information from the
following webpage and display it on your monitor:
https://weather.naver.com/rgn/cityWetrCity.nhn?cityRgnCd=CT007023
You would start with opening the webpage, then write the information in the
webpage in a HTML file, "./montp.html", and finally open the latter file in a
web browser to display the weather info in the file.
'''
#problem 3 : Extracting Data From HTML

import urllib.request
url = "https://weather.naver.com/rgn/cityWetrCity.nhn?cityRgnCd=CT007023"
fname = "./montp.html"
dates = []
min_tp = []
max_tp = []

#Extract weather info from webpage then print
def main():
    process_webpage()
    print_weather()

#Get url from the webpage and save in file
def process_webpage():
    webpage = urllib.request.urlopen(url)
    out = open(fname, "w")
    for line in webpage :
        line = str(line)
        out.write(line.strip() + "\n")
    webpage.close()
    out.close()

#Read file and Print out weather information
def print_weather():
    f = open('montp.html', "r")
    min_flag = True
    for line in f:
        if '<th scope="col"' in line:
            wdate = extract_date(line)
            dates.append(wdate)
        elif '<th scope="row"' in line:
            wdate = extract_date(line)
            dates.append(wdate)
        elif '<li class="nm">' in line:
            temp = extract_temperature(line)
            if min_flag == True:
                min_tp.append(temp)
                min_flag = False
            else:
                max_tp.append(temp)
                min_flag = True
    for i in range(len(dates)):
        print("%s :\t%5s ~ %5s" % (dates[i], min_tp[i], max_tp[i]))
    f.close()

#Extract date info from a line
'''
parameter:
'''
def extract_date(line):
    if "<span>(" in line:
        tdate = line[ line.find("(") + 1 : line.find(")") ]
    else:
        skip_len = len( "<span>" )
        start_idx = line.find("<span>") + skip_len
        tdate = line[ start_idx : line.find("<", start_idx)]
        tdate = tdate.strip(".")
        tdate = tdate.replace(".", "/")
    return tdate

#Extract temperature info from a line
'''
parameter:
'''
def extract_temperature(line):
    skip_len = len('<span class="temp">')
    start_idx = line.find('<span class="temp">') + skip_len
    end_idx = line.find("<", start_idx)
    temp = line[ start_idx : end_idx ]
    return temp

main()
